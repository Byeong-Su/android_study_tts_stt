package com.example.google_tts_stt;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.security.Permission;
import java.util.ArrayList;
import java.util.Locale;

import static java.lang.Thread.sleep;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener{

    Context Cthis=this;

    //sms 퍼미션용
    static final int SMS_RECEIVE_PERMISSON=1;

    //수신받은 sms정보
    private String sender, content, date;

    Intent intent;
    SpeechRecognizer mRecognizer;
    TextView textView;
    final int PERMISSION = 1;

    private TextToSpeech tts;
    private Button btn_Speak,sttBtn,Boradcast_btn;
    private EditText txtText;

    private String input_stt="";

    //스레드 객체
    DetectThread detectThread = new DetectThread();

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(Build.VERSION.SDK_INT >=23){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET, Manifest.permission.RECORD_AUDIO},PERMISSION);
        }

        textView = (TextView)findViewById(R.id.sttResult);
        sttBtn = (Button) findViewById(R.id.sttStart);

        tts = new TextToSpeech(this, this);
        btn_Speak = findViewById(R.id.btnSpeak);
        txtText = findViewById(R.id.txtText);

        Boradcast_btn = (Button)findViewById(R.id.btnAlternative);

        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,getPackageName());
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ko-KR");


        //문자수신 권한이 부여되어 있는지 확인
        int permissonCheck= ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS);

        if(permissonCheck == PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(), "SMS 수신권한 있음", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(), "SMS 수신권한 없음", Toast.LENGTH_SHORT).show();

            //권한설정 dialog에서 거부를 누르면
            //ActivityCompat.shouldShowRequestPermissionRationale 메소드의 반환값이 true가 된다.
            //단, 사용자가 "Don't ask again"을 체크한 경우
            //거부하더라도 false를 반환하여, 직접 사용자가 권한을 부여하지 않는 이상, 권한을 요청할 수 없게 된다.
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECEIVE_SMS)){
                //이곳에 권한이 왜 필요한지 설명하는 Toast나 dialog를 띄워준 후, 다시 권한을 요청한다.
                Toast.makeText(getApplicationContext(), "SMS권한이 필요합니다", Toast.LENGTH_SHORT).show();
                ActivityCompat.requestPermissions(this, new String[]{ Manifest.permission.RECEIVE_SMS}, SMS_RECEIVE_PERMISSON);
            }else{
                ActivityCompat.requestPermissions(this, new String[]{ Manifest.permission.RECEIVE_SMS}, SMS_RECEIVE_PERMISSON);
            }
        }




        //스레드 시작
        //detectThread.start();

        //문자 출력?!
        Intent passedIntent = getIntent();
        processIntent(passedIntent);

        Boradcast_btn.setOnClickListener(v -> {
            tts.setPitch((float)1.0);
            tts.setSpeechRate((float)1.0);
            tts.speak("문자메시지가 도착했습니다. 답장 하시겠습니까?", TextToSpeech.QUEUE_FLUSH, null);
            try{
                sleep(5000);
                mRecognizer=SpeechRecognizer.createSpeechRecognizer(this);
                mRecognizer.setRecognitionListener(listener);
                mRecognizer.startListening(intent);
                sleep(100);
            }catch (Exception e){
                e.printStackTrace();
            }

            if(input_stt.equals("답장")){
                input_stt = "";
                tts.setPitch((float)1.0);
                tts.setSpeechRate((float)1.0);
                tts.speak("답장내용을 말해주세요.", TextToSpeech.QUEUE_FLUSH, null);
                try{
                    sleep(2500);
                    mRecognizer=SpeechRecognizer.createSpeechRecognizer(this);
                    mRecognizer.setRecognitionListener(listener);
                    mRecognizer.startListening(intent);
                    sleep(100);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            if(input_stt.length()>1){
                input_stt = "";
                tts.setPitch((float)1.0);
                tts.setSpeechRate((float)1.0);
                tts.speak("답장을 전송합니다.", TextToSpeech.QUEUE_FLUSH, null);
            }
        });

        /*sttBtn.setOnClickListener(v -> {
            mRecognizer=SpeechRecognizer.createSpeechRecognizer(this);
            mRecognizer.setRecognitionListener(listener);
            mRecognizer.startListening(intent);
        });*/

        /*btn_Speak.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v) {
                speakOut();
            }
        });*/
    }

    private RecognitionListener listener = new RecognitionListener() {
        @Override
        public void onReadyForSpeech(Bundle params) {
            Toast.makeText(getApplicationContext(), "음성인식을 시작합니다.", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onBeginningOfSpeech() {
        }

        @Override
        public void onRmsChanged(float rmsdB) {
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
        }

        @Override
        public void onError(int error) {
            String message;

            switch (error) {
                case SpeechRecognizer.ERROR_AUDIO:
                    message = "오디오 에러";
                    break;
                case SpeechRecognizer.ERROR_CLIENT:
                    message = "클라이언트 에러";
                    break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    message = "퍼미션 없음";
                    break;
                case SpeechRecognizer.ERROR_NETWORK:
                    message = "네트워크 에러";
                    break;
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                    message = "네트웍 타임아웃";
                    break;
                case SpeechRecognizer.ERROR_NO_MATCH:
                    message = "찾을 수 없음";
                    break;
                case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                    message = "RECOGNIZER가 바쁨";
                    break;
                case SpeechRecognizer.ERROR_SERVER:
                    message = "서버가 이상함";
                    break;
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    message = "말하는 시간초과";
                    break;
                default:
                    message = "알 수 없는 오류임";
                    break;
            }
            Toast.makeText(getApplicationContext(), "에러가 발생하였습니다. : " + message, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onResults(Bundle results) {
            // 말을 하면 ArrayList에 단어를 넣고 textView에 단어를 이어줍니다.
            ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            for (int i = 0; i < matches.size(); i++) {
                //textView.setText(matches.get(i));

                input_stt=matches.get(i);

                Toast.makeText(getApplicationContext(),input_stt,Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onPartialResults(Bundle partialResults) {        }

        @Override
        public void onEvent(int eventType, Bundle params) {        }
    };

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void speakOut(){
        CharSequence text = txtText.getText();
        tts.setPitch((float)0.6);
        tts.setSpeechRate((float)0.1);
        tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"id1");
    }

    @Override
    public void onDestroy(){
        if(tts != null){
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onInit(int status){
        if(status == TextToSpeech.SUCCESS){
            int result = tts.setLanguage(Locale.KOREA);

            if(result==TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED){
                Log.e("TTS","This Language is not supported");
            }else{
                btn_Speak.setEnabled(true);
                speakOut();
            }
        }else{
            Log.e("TTS","Initilization Failed!");
        }
    }


    private class DetectThread extends Thread {
        private static final String TAG = "ExampleThread";
        public DetectThread() { /*초기화 작업 */ }
        public void run() {
            // 스레드에게 수행시킬 동작들 구현
            while(true) {
                if (input_stt.indexOf("답장") > -1) {
                    input_stt = "";
                    //Toast.makeText(getApplicationContext(),"답장을 보낸다.",Toast.LENGTH_SHORT).show();
                    Log.v("logcat","스레드동작");
                    /*
                    try {
                        tts.setPitch((float) 1.0);
                        tts.setSpeechRate((float) 1.0);
                        tts.speak("문자메시지를 보냅니다.", TextToSpeech.QUEUE_FLUSH, null);
                        sleep(3000);


                    } catch (Exception e) {
                        e.printStackTrace();
                    }*/
                }
            }
        }
    }


    /** 얘가 중요 **/
    private void processIntent(Intent intent){
        if(intent != null){
            // 인텐트에서 전달된 데이터를 추출하여, 활용한다.(여기서는 edittext를 통하여 내용을 화면에 뿌려주었다.)
            sender = intent.getStringExtra("sender");
            content = intent.getStringExtra("contents");
            date = intent.getStringExtra("receivedDate");

            Toast.makeText(getApplicationContext(),sender+content+date,Toast.LENGTH_LONG).show();

            try{
                tts.speak(sender+"에게 온 메시지입니다." + content,TextToSpeech.QUEUE_FLUSH,null);
                sender = "";
                content = "";
                date = "";
                sleep(7000);
            } catch (Exception e){
                e.printStackTrace();
            }


        }
    }

    // (2) 이미 실행된 상태였는데 리시버에 의해 다시 켜진 경우
    // (이러한 경우 onCreate()를 거치지 않기 때문에 이렇게 오버라이드 해주어야 모든 경우에 SMS문자가 처리된다!
    @Override
    protected void onNewIntent(Intent intent) {
        processIntent(intent);

        super.onNewIntent(intent);
    }

}